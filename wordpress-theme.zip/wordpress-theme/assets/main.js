(function($) {
    // Весь ваш jQuery код здесь
    $(document).ready(function() {
        $('#lop').click(function() {
            $('#dropdown-menu').toggle(); // Показать или скрыть меню
        });
    });
})(jQuery);
