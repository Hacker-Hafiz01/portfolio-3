<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wordpress
 */

get_header();
?>

 <!-- NAVBAR 2 START -->
 <div class="nav2">
        <ul>
            <li>Plugins</li>
            <li>Themes</li>
            <li>Videos</li>
            <li>Photos</li>
        </ul>
     </div>
    <!-- NAVBAR 2 FINISH -->

    <!-- BODY START 1 -->
    <div class="start-bd">
        
        <!-- ABOUT WEBSITE -->
        <div class="serthem">
            <h1>Professional WordPress Themes & Website <br>
                 Templates for any project</h1>
            <p>Discover thousands of easy to customize themes, templates & CMS products, <br>
                 made by world-class developers.</p>

                 <!-- SEARCH TO PRODUCTS -->
            <div class="inser">
            <input  placeholder="search a theme" type="text" class="themser">
            <button class="btn-inser" type="button">search</button>
            </div>
        </div>
        <!-- BIG IMG -->
        <div class="img-them">
            <img class="web" src="<?php echo get_template_directory_uri(  ); ?>/img/products/start-t.webp" alt="">
        </div>
    </div>

    <!-- BODY START 1 FINISH -->

    <div id="products-items" class="option">
        
        <!-- PRODUCT 1 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="https://hacker-hafiz01.github.io/portfolio-2/">prewiev</a></button><br>
         <div>
         <img class="imeg" src="<?php echo get_template_directory_uri() ?>/img/products/product-tree.webp" alt="">
        </div>
        </div>
        
        <!-- PRODUCT 2 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="https://hacker-hafiz01.github.io/app-portfolio-1/">prewiev</a></button><br>
          <img class="imeg" src="<?php echo get_template_directory_uri() ?>/img/products/product-tree.webp" alt="">
         </div>
        
         <!-- PRODUCT 3 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
         <img class="imeg" src="<?php echo get_template_directory_uri() ?>/img/products/product-tree.webp" alt="">
        </div> 
        
        <!-- PRODUCT 4 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
          <img class="imeg" src="https://softbenz.com/media/blog/blog-1637755217.jpg" alt="">
         </div>
        
         <!-- PRODUCT 5 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
          <img class="imeg" src="https://motopress.com/wp-content/uploads/edd/2020/11/albatross-screeen-long-446x423.jpg" alt="">
         </div>
        
         <!-- PRODUCT 6 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
         <img class="imeg" src="https://www.cloudways.com/blog/wp-content/uploads/premium-wordpress-themes-pr.jpg" alt="">
        </div>
        
        <!-- PRODUCT 7 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
         <img class="imeg" src="https://www.radiustheme.com/wp-content/uploads/2020/10/Best-Minimalist-WordPress-Themes.jpg" alt="">
        </div>
         <!-- PRODUCT 8 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
         <img class="imeg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1uq1cMWz5IfU03PIrIG2GSFlXDgpzX3r7dg&s" alt="">
        </div>
        
        <!-- PRODUCT 9 -->
        <div class="product">
         <h1>WordPress Theme</h1><br>
         <p>Wordpress theme with <br>
            Elementor</p><br>
         <button class="hv"><a href="#">prewiev</a></button><br>
         <img class="imeg" src="https://www.bluchic.com/wp-content/uploads/2024/02/momentum-elementor-wordpress-theme.jpg" alt="">
        </div>
    </div>

	

<?php
// get_sidebar();
get_footer();
?>