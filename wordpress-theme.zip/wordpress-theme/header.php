<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wordpress
 */

?>
<?php wp_head(); ?>

<!DOCTYPE html>
<!-- LANGUAGE OF WEBSITE -->
<html lang="en">
<head>
    <!-- META TAGS START -->
    <meta charset="UTF-8">
    <meta name="author" content="theme-software-engineering">
    <!-- META TAGS FINISH -->
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon/favicon1.png" type="image/x-icon">

    <title>MuvoTheme</title>
</head>
<body>
    <!-- HEADER START -->
    <header>
        <div class="head">

            <!-- LOGO START -->
            <div class="logo" >

                <div>
             <img src="<?php echo get_template_directory_uri(); ?>/img/logo/logo1.png" alt="">
                </div>

                <div>
             <h1>MuvoTheme</h1>
                </div>
            </div>
            <!-- LOGO FINISH -->
        
     <!-- NAVBAR START -->
         <div class="navigator">
             <div class="lokm"> 
                 <ul class="menu-el"> 

                <span id="lop" class="material-icons">
                    menu
                    </span>
                    <div id="dropdown-menu" style="display: none;">
                        <!-- Здесь содержимое вашего выпадающего меню -->
                        <ul>
                            <li class="elik"><a href="#">start seling</a></li>
                            <li class="elik"><a href="#">our products</a></li>
                            <li class="elik"><a href="#">sign in</a></li>
                        </ul>
                    </div>
                    
                    
                </ul>
            </div>
             <div class="nav1">
            <nav>
            <ul>
                <li>forums</li>
                
                <li><a href="https://wordpress.org/support/forums/">start seling</a></li>

                <div class="icon">
                <span id="products" class="material-icons">
                    menu
                    </span>
                </div>
                <li id="products"><a href="">our products</a></li>
                <div class="icon">
                <span id="products" class="material-icons">
                    shopping_cart
                    </span>
                </div>
                <li><a href="">sign in</a></li>
            </ul>
            </div>
            </nav>
        
         </div>
     <!-- NAVBAR FINISH -->
        </div>
      
    </header>