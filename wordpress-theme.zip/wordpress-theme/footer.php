<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wordpress
 */

?>

	 <!-- FOOTER START -->
     <footer>
        <!-- CONTACT START -->
        <p class="end"><a href="mailto:test@gmail.com">test@mail.com</a>
         <a href="tel:+879 555 555 55 55"> +879 555 555 55 55</a></p>
         <!-- CONTACT FINISH -->
    </footer>
</body>
</html>

<?php wp_footer(); ?>


